﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SnakesAndLaddersGame;

namespace UnitTestProject
{
    [TestClass]
    public class SettingsValidatorTests
    {
        SettingsValidator settingsValidator = new SettingsValidator();
        [TestMethod]
        public void IncorrectMinimumValueTest()
        {
            string actualString = settingsValidator.ValidateMinimumMaximumValues(50, 20);
            string expectedSTring = $"Minimum value on the board -  50 is not less than the maximum value on the board - 20{Environment.NewLine}";
            Assert.AreEqual(expectedSTring, actualString);
        }

        [TestMethod]
        public void IncorrectMaximumValueTest()
        {
            string actualString = settingsValidator.ValidateMinimumMaximumValues(100, 20);
            string expectedSTring = $"Minimum value on the board -  100 is not less than the maximum value on the board - 20{Environment.NewLine}";
            Assert.AreEqual(expectedSTring, actualString);
        }

        [TestMethod]
        public void IncorrectSnakeValue()
        {
            string actualString = settingsValidator.ValidateSnakeOrLadderValues(10, 20,0,100, true);
            string expectedSTring = $"Start Value for Snake(10) must be higher End Value for Snake(20){Environment.NewLine}";
            Assert.AreEqual(expectedSTring, actualString);
        }


        [TestMethod]
        public void IncorrectLadderValue()
        {
            string actualString = settingsValidator.ValidateSnakeOrLadderValues(100, 20,0,100, false);
            string expectedSTring = $"Start Value for Ladder(100) must be lower than End Value for Ladder(20){Environment.NewLine}";
            Assert.AreEqual(expectedSTring, actualString);
        }

        [TestMethod]
        public void IncorrectMinimumSnakeLadderValue()
        {
            string actualString = settingsValidator.ValidateSnakeOrLadderValues(60, 20, 30, 100, true);
            string expectedSTring = $"{string.Empty}Value Pair - 60:20 has a value less than minimum value on the board(30){Environment.NewLine}";
            Assert.AreEqual(expectedSTring, actualString);
        }

        [TestMethod]
        public void IncorrectMaximumSnakeLadderValue()
        {
            string actualString = settingsValidator.ValidateSnakeOrLadderValues(30, 100, 0, 50, false);
            string expectedSTring = $"{string.Empty}Value Pair - {30}:{100} has a value greater than maximum value on the board(50){Environment.NewLine}";
            Assert.AreEqual(expectedSTring, actualString);
        }

        [TestMethod]
        public void CorrectMinimumValueTest()
        {
            string actualString = settingsValidator.ValidateMinimumMaximumValues(0, 20);
            string expectedSTring = "Minimum value 50 is not less than the maximum value 20";
            Assert.AreNotEqual(expectedSTring, actualString);
        }

        [TestMethod]
        public void CorrectMaximumValueTest()
        {
            string actualString = settingsValidator.ValidateMinimumMaximumValues(0, 100);
            string expectedSTring = "Minimum value 100 is not less than the maximum value 20";
            Assert.AreNotEqual(expectedSTring, actualString);
        }

        [TestMethod]
        public void CorrectSnakeValue()
        {
            string actualString = settingsValidator.ValidateSnakeOrLadderValues(40, 20,0,100, true);
            string expectedSTring = "Start Value 10 for Snake must be higher End Value 20 for Snake";
            Assert.AreNotEqual(expectedSTring, actualString);
        }


        [TestMethod]
        public void CorrectLadderValue()
        {
            string actualString = settingsValidator.ValidateSnakeOrLadderValues(10, 60,0,100, false);
            string expectedSTring = "Start Value 100 for Ladder must be lower than End Value 20 for Ladder";
            Assert.AreNotEqual(expectedSTring, actualString);
        }
    }
}
