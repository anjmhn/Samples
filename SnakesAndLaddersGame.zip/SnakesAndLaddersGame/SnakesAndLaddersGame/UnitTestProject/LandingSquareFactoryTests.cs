﻿using System;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SnakesAndLaddersGame;
using SnakesAndLaddersGame.LandingSquare;

namespace UnitTestProject
{
    [TestClass]
    public class LandingSquareFactoryTests
    {
        private Dictionary<int, int> _laddersDictionary = new Dictionary<int, int>();
        private Dictionary<int, int> _snakesDictionary = new Dictionary<int, int>();
        public LandingSquareFactoryTests()
        {
            _snakesDictionary = InitializeSnakesDictionary();
            _laddersDictionary = InitializeLadderDictionary();
        }

        [TestMethod]
        public void SnakeSquareTest()
        {
            Dictionary<string, string> diceValues = new Dictionary<string, string>();
            GameHandler gameHandler = new GameHandler(2, 10, diceValues);
            LandingSquareFactory landingFactory = gameHandler.GetLandingSquareFactory(25, 21, 100, _snakesDictionary, null);
            int actual = landingFactory.GetLandingSquareValue(25);
            Assert.AreEqual(10, actual);

        }

        [TestMethod]
        public void LadderSquareTest()
        {
            Dictionary<string, string> diceValues = new Dictionary<string, string>();

            GameHandler gameHandler = new GameHandler(2, 10, diceValues);
            LandingSquareFactory landingFactory = gameHandler.GetLandingSquareFactory(26, 21, 100, _snakesDictionary, _laddersDictionary);
            int actual = landingFactory.GetLandingSquareValue(26);
            Assert.AreEqual(60, actual);

        }

        [TestMethod]
        public void RegularSquareTest()
        {
            Dictionary<string, string> diceValues = new Dictionary<string, string>();
            GameHandler gameHandler = new GameHandler(2, 10, diceValues);
            LandingSquareFactory landingFactory = gameHandler.GetLandingSquareFactory(55, 52, 100, _snakesDictionary, _laddersDictionary);
            int actual = landingFactory.GetLandingSquareValue(55);
            Assert.AreEqual(55, actual);

        }

        [TestMethod]
        public void RegularSquareTestForMoreThanMaxValue()
        {
            Dictionary<string, string> diceValues = new Dictionary<string, string>();
            GameHandler gameHandler = new GameHandler(2, 10, diceValues);
            LandingSquareFactory landingFactory = gameHandler.GetLandingSquareFactory(105, 99, 100, _snakesDictionary, _laddersDictionary);
            bool gameEndsOnlyOnExactMatch = Convert.ToBoolean(ConfigurationManager.AppSettings["GameEndsOnlyOnExactMatch"]);
            int expected = gameEndsOnlyOnExactMatch ? 99 : 100;
            int actual = landingFactory.GetLandingSquareValue(105);
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void IncorrectRegularSquareTestForMoreThanMaxValue()
        {
            Dictionary<string, string> diceValues = new Dictionary<string, string>();
            GameHandler gameHandler = new GameHandler(2, 10, diceValues);
            LandingSquareFactory landingFactory = gameHandler.GetLandingSquareFactory(105, 99, 100, _snakesDictionary, _laddersDictionary);
            int actual = landingFactory.GetLandingSquareValue(105);
            Assert.AreNotEqual(105, actual);
        }


        private Dictionary<int, int> InitializeLadderDictionary()
        {
            Dictionary<int, int> laddersDictionary = new Dictionary<int, int>();
            laddersDictionary.Add(26, 60);
            laddersDictionary.Add(38, 85);
            return laddersDictionary;
        }

        private Dictionary<int, int> InitializeSnakesDictionary()
        {
            Dictionary<int, int> snakesDictionary = new Dictionary<int, int>();
            snakesDictionary.Add(25, 10);
            snakesDictionary.Add(38, 15);
            return snakesDictionary;
        }
    }
}
