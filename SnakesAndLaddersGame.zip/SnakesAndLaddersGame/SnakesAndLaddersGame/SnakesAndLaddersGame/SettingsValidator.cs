﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersGame
{
    public class SettingsValidator
    {
        public string ValidateMinimumMaximumValues(int minValue, int maxValue)
        {
            string validationFailedMessage = string.Empty;

            if (minValue >= maxValue)
                validationFailedMessage = $"Minimum value on the board -  {minValue} is not less than the maximum value on the board - {maxValue}{Environment.NewLine}";

            return validationFailedMessage;
        }
        public string ValidateSnakeOrLadderValues(int startVal, int endVal, int minValue, int maxValue, bool isSnake)
        {
            string validationFailedMessage = string.Empty;
            switch (isSnake)
            {
                case true:
                    if (startVal <= endVal)
                        validationFailedMessage = $"Start Value for Snake({startVal}) must be higher End Value for Snake({endVal}){Environment.NewLine}";
                    break;
                case false:
                    if (startVal >= endVal)
                        validationFailedMessage = $"Start Value for Ladder({startVal}) must be lower than End Value for Ladder({endVal}){Environment.NewLine}";
                    break;
            }
            if (startVal < minValue || endVal < minValue)
                validationFailedMessage = $"{validationFailedMessage}Value Pair - {startVal}:{endVal} has a value less than minimum value on the board({minValue}){Environment.NewLine}";
            if (startVal > maxValue || endVal > maxValue)
                validationFailedMessage = $"{validationFailedMessage}Value Pair - {startVal}:{endVal} has a value greater than maximum value on the board({maxValue}){Environment.NewLine}";

            return validationFailedMessage;
        }

    }
}
