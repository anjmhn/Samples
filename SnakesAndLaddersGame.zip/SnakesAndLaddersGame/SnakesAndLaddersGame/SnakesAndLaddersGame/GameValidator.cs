﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersGame
{
    public class GameValidator
    {
        private int _boardMinimumValue;
        private int _boardMaximumValue;

        private Dictionary<int, int> _snakesDictionary = new Dictionary<int, int>();
        private Dictionary<int, int> _laddersDictionary = new Dictionary<int, int>();

        private const string VALIDATION_FAILED = "Validation Failed ";
        public GameValidator(Dictionary<int, int> snakesDictionary, Dictionary<int, int> ladderDictionary, int boardMinimumValue, int boardMaximumValue)
        {
            _boardMinimumValue = boardMinimumValue;
            _boardMaximumValue = boardMaximumValue;
            _snakesDictionary = snakesDictionary;
            _laddersDictionary = ladderDictionary;
        }

        internal string ValidateBeforePlaying()
        {
            return ValidateSettings();
        }

        private string ValidateSettings()
        {
            StringBuilder sb = new StringBuilder();
            SettingsValidator settingsValidator = new SettingsValidator();
            sb.Append(ValidateMinimumMaximumValues(settingsValidator));
            sb.Append(ValidateValuesforSnakesAndLadders(settingsValidator, false));
            string returnString = sb.ToString();
            returnString = String.IsNullOrEmpty(returnString) ? returnString : VALIDATION_FAILED +Environment.NewLine+ returnString;
            return returnString;
        }

        private string ValidateMinimumMaximumValues(SettingsValidator settingsValidator)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(settingsValidator.ValidateMinimumMaximumValues(_boardMinimumValue, _boardMaximumValue));
            return sb.ToString();
        }
        private string ValidateValuesforSnakesAndLadders(SettingsValidator settingsValidator, bool isSnakeValue)
        {
            StringBuilder sb = new StringBuilder();
            Dictionary<int, int> dict = new Dictionary<int, int>();
            dict = isSnakeValue ? _snakesDictionary : _laddersDictionary;
            foreach (KeyValuePair<int, int> kvp in dict)
                sb.Append(settingsValidator.ValidateSnakeOrLadderValues(kvp.Key, kvp.Value, _boardMinimumValue, _boardMaximumValue, isSnakeValue));
            return sb.ToString();
        }

    }
}
