﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;

namespace SnakesAndLaddersGame
{
    public class PrepForGame
    {
        private string _diceValuesFile;
        private int _maxNumberOfPlayers;
        private int _maxDiceRolls;
        private int _boardMinimumValue;
        private int _boardMaximumValue;
        private Dictionary<string, string> _diceValues = new Dictionary<string, string>();
        private Dictionary<int, int> _snakesDictionary = new Dictionary<int, int>();
        private Dictionary<int, int> _laddersDictionary = new Dictionary<int, int>();

        internal string Start()
        {
            try
            {
                InitializeValues();
                GameValidator gameValidator = new GameValidator(_snakesDictionary, _laddersDictionary, _boardMinimumValue, _boardMaximumValue);
                string returnString = gameValidator.ValidateBeforePlaying();
                if (string.IsNullOrEmpty(returnString))
                {
                    CreateDiceValuesFile();
                    _diceValues = ReadFromFile();
                    GameHandler gameHandler = new GameHandler(_maxNumberOfPlayers, _maxDiceRolls, _diceValues);
                    returnString = gameHandler.PlayGame(_boardMinimumValue, _boardMaximumValue, _snakesDictionary, _laddersDictionary);
                }
                return returnString;
            }
            catch (Exception ex)
            {
                throw new Exception($"{ex.Message.ToString()} : {ex.StackTrace.ToString()}");
            }

        }

        private void InitializeValues()
        {
            _diceValuesFile = ConfigurationManager.AppSettings["DiceValuesFile"].ToString();
            _maxNumberOfPlayers = Convert.ToInt32(ConfigurationManager.AppSettings["MaximumNumberOfPlayers"]);
            _maxDiceRolls = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDiceRolls"]);
            _snakesDictionary = CreateDictionary(ConfigurationManager.AppSettings["Snakes"]);
            _laddersDictionary = CreateDictionary(ConfigurationManager.AppSettings["Ladders"]);
            _boardMinimumValue = Convert.ToInt32(ConfigurationManager.AppSettings["BoardMinimumValue"]);
            _boardMaximumValue = Convert.ToInt32(ConfigurationManager.AppSettings["BoardMaximumValue"]);
        }

        private Dictionary<int, int> CreateDictionary(string value)
        {
            Dictionary<int, int> dict = new Dictionary<int, int>();
            foreach (string val in value.Split(','))
            {
                string[] valSplit = val.Split(':');
                dict.Add(Convert.ToInt32(valSplit[0]), Convert.ToInt32(valSplit[1]));
            }
            return dict;
        }
        private void CreateDiceValuesFile()
        {
            StringBuilder sb = new StringBuilder();
            Random random = new Random();
            for (int i = 1; i <= _maxNumberOfPlayers; i++)
            {
                sb.Append($"Player{i}:");

                for (int count = 0; count < _maxDiceRolls; count++)
                {
                    sb.Append(random.Next(1, 7));
                }
                sb.AppendLine();
            }
            File.WriteAllText(_diceValuesFile, sb.ToString());
        }
        private Dictionary<string, string> ReadFromFile()
        {
            foreach (string line in File.ReadAllLines(_diceValuesFile))
            {
                string[] lineSplit = line.Split(':');
                _diceValues.Add(lineSplit[0], lineSplit[1]);
            }
            return _diceValues;
        }


    }
}
