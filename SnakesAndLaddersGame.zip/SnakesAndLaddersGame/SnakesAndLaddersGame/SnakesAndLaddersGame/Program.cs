﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersGame
{
    class Program
    {
        private const string VALIDATION_FAILED = "Validation Failed ";
        static void Main(string[] args)
        {

            try
            {
                PrepForGame prepForGame = new PrepForGame();
                string returnString = prepForGame.Start();
                if (returnString.StartsWith(VALIDATION_FAILED))
                {
                    Console.WriteLine($"Invalid values found in Configuration. Please correct and play again  - {returnString}");
                    Console.Read();
                }
                else
                {
                    Console.WriteLine($"Congratulations we have a WINNER!!!  {Environment.NewLine}{returnString}");
                    Console.Read();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.Read();
            
            }
        }
    }
}
