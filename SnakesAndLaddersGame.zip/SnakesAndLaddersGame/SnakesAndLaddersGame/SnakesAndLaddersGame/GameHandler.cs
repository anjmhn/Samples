﻿using SnakesAndLaddersGame.LandingSquare;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersGame
{
    public class GameHandler
    {
        private int _maxNumberOfPlayers;
        private int _maxDiceRolls;
        private string _logFile;
        private List<int> _currentSquareForEachPlayer = new List<int>();
        private Dictionary<string, string> _diceValuesDictionary = new Dictionary<string, string>();


        public GameHandler(int maxNumberOfPlayers, int maxDiceRolls, Dictionary<string, string> diceValues)
        {
            _maxNumberOfPlayers = maxNumberOfPlayers;
            _maxDiceRolls = maxDiceRolls;
            _diceValuesDictionary = diceValues;
            CreateLogFile();
        }

        private void CreateLogFile()
        {
            _logFile = ConfigurationManager.AppSettings["LogFile"].ToString();
            File.WriteAllText(_logFile, $"Game Started: {DateTime.Now.ToString()} {Environment.NewLine}");
        }

        internal string PlayGame(int boardMinimumValue, int boardMaximumValue, Dictionary<int, int> snakesDictionary, Dictionary<int, int> laddersDictionary)
        {
            string player = string.Empty;
            for (int i = 1; i <= _maxNumberOfPlayers; i++)
                _currentSquareForEachPlayer.Add(boardMinimumValue);

            while (string.IsNullOrEmpty(player))
            {
                player = Play(boardMaximumValue, snakesDictionary, laddersDictionary);
            }
            return player;
        }


        private string Play(int boardMaximumValue, Dictionary<int, int> snakesDictionary, Dictionary<int, int> laddersDictionary)
        {
            string gameInfo = string.Empty;
            bool endOfGame = false;

            for (int count = 0; count < _maxDiceRolls; count++)
            {
                for (int i = 0; i < _maxNumberOfPlayers; i++)
                {
                    string playerInfo = $"Player{i + 1}";
                    File.AppendAllText(_logFile, $"Player {i + 1} - Turn {count + 1} {Environment.NewLine}");
                    int diceValue = Convert.ToInt32(_diceValuesDictionary[playerInfo].Substring(count, 1));
                    int currentSquareValue = Convert.ToInt32(_currentSquareForEachPlayer[i]);
                    File.AppendAllText(_logFile, $"Current DiceValue  - {diceValue}{Environment.NewLine}");
                    int newSquareValue = diceValue + currentSquareValue;
                    LandingSquareFactory landingSquareFactory = GetLandingSquareFactory(newSquareValue, currentSquareValue, boardMaximumValue, snakesDictionary, laddersDictionary);
                    int result = landingSquareFactory.GetLandingSquareValue(newSquareValue);
                    _currentSquareForEachPlayer[i] = result;
                    File.AppendAllText(_logFile, $"Player {i + 1} moves from {currentSquareValue} to {result}{Environment.NewLine}{Environment.NewLine}");
                    if (result >= boardMaximumValue)
                    {
                        gameInfo = GetInfoForEachPlayer(i+1);
                        endOfGame = true;
                        break;
                    }
                }
                if (endOfGame)
                    break;
            }
            return gameInfo; ;
        }

        private string GetInfoForEachPlayer(int i)
        {
            StringBuilder sb = new StringBuilder();
            int count = 1;
            foreach (int val in _currentSquareForEachPlayer)
            {
                sb.AppendLine($"Player{count} is on Square {val}");
                count++;
            }
            sb.AppendLine($"Player{i} has won this game!!!");

            return sb.ToString();
        }

        public LandingSquareFactory GetLandingSquareFactory(int newSquareValue, int currentSquareValue, int boardMaximumValue, Dictionary<int, int> snakesDictionary, Dictionary<int, int> laddersDictionary)
        {

            if (snakesDictionary.ContainsKey(newSquareValue))
            {
                File.AppendAllText(_logFile, $"Snake :( - {newSquareValue}{Environment.NewLine}");
                return new SnakeSquare(currentSquareValue, boardMaximumValue, snakesDictionary);
            }
            if (laddersDictionary.ContainsKey(newSquareValue))
            {
                File.AppendAllText(_logFile, $"Ladder :) - {newSquareValue}{Environment.NewLine}");
                return new LadderSquare(currentSquareValue, boardMaximumValue, laddersDictionary);
            }
            return new RegularSquare(currentSquareValue, boardMaximumValue, null);
        }
    }
}
