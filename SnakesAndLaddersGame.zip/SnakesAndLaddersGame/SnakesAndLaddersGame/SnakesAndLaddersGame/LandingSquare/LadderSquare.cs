﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersGame.LandingSquare
{
    public class LadderSquare : LandingSquareFactory
    {
        public LadderSquare(int currentSquareValue, int maximumBoardValue, Dictionary<int, int> dict) : base(currentSquareValue, maximumBoardValue, dict)
        {
        }

        public override int GetLandingSquareValue(int num)
        {
            int value = 0;
            _dict.TryGetValue(num, out value);
            return value;
        }
    }
}
