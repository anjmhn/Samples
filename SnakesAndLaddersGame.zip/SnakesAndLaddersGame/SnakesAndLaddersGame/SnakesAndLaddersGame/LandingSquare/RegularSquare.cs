﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersGame.LandingSquare
{
    public class RegularSquare : LandingSquareFactory
    {
        public RegularSquare(int currentSquareValue, int maximumBoardValue, Dictionary<int, int> dict) : base(currentSquareValue, maximumBoardValue, dict)
        {
        }
        public override int GetLandingSquareValue(int num)
        {
            int val = num;
            if (num > _maximumBoardValue)
            {
                val =Convert.ToBoolean(ConfigurationManager.AppSettings["GameEndsOnlyOnExactMatch"]) ? _currentSquareValue : _maximumBoardValue;
            }
            return val;
        }
    }
}
