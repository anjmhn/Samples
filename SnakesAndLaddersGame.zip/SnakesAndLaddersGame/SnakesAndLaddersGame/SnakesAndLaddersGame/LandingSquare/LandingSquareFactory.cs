﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersGame.LandingSquare
{
    public abstract class LandingSquareFactory
    {
        protected Dictionary<int, int> _dict = new Dictionary<int, int>();
        protected int _maximumBoardValue;
        protected int _currentSquareValue;

        public LandingSquareFactory()
        { }
        public LandingSquareFactory(int currentSquareValue, int maximumBoardValue, Dictionary<int, int> dict)
        {
            _dict = dict;
            _maximumBoardValue = maximumBoardValue;
            _currentSquareValue = currentSquareValue;
        }
        public abstract int GetLandingSquareValue(int num);

    }
}
